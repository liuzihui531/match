<div class="show">
	<div class="show_tit">青年农村电商大赛报名系统</div>
    <div class="show_form">

    	<form action="<?php echo $this->createUrl("login") ?>" method="post" class="bootstrap-frm" >
        <h2>登录系统<span>已报名用户可登录并进行抽签。如果您无法登录，请致电：0898-66729363 咨询。<br />请注意：未报名用户禁止登录。</h2>
        	<label>
				<span>登录账号 :</span>
				<input id="" type="text" name="email" placeholder="请输入手机号或E-mail" />*
			</label>
            <label>
				<span>登录密码:</span>
				<input id="" type="text" name="password" placeholder="请输入登录密码" />*
			</label>
            <label>
			<span>&nbsp;</span>
			<input type="submit" class="button" value="提交" />
			</label>
        </form>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
    </div>
</div>

<div class="footer">
    <div class="footer_con">
        <p>海南青年创业就业服务中心</p>
        <p>© 2016 Hcyc.cn 版权所有 ICP证：琼ICP备16002852号</p>
    </div>
</div>
</div>
